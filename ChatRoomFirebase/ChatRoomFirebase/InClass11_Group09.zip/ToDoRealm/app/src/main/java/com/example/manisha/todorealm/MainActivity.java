package com.example.manisha.todorealm;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.ocpsoft.prettytime.PrettyTime;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Random;

import io.realm.OrderedCollectionChangeSet;
import io.realm.OrderedRealmCollectionChangeListener;
import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmResults;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Button buttonAdd;
    EditText editText;
    ListView listView;
    String task,priority;
    ArrayList<Task> list;
    ArrayList<Task> listCompleted;
    ArrayList<Task> listPending;
    String display="abc";
    Realm realm;
    Spinner spinnerPriority;
    RealmResults<Task> taskRealmResults;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.showcompleted){
            // do something
            Adapterclass adapterCompleted = new Adapterclass(MainActivity.this,listCompleted);
            listView.setAdapter(adapterCompleted);
            display = "completed";
        }
        else if(id==R.id.showpending){
            Adapterclass adapterPending = new Adapterclass(MainActivity.this,listPending);
            listView.setAdapter(adapterPending);
            display = "pending";
        }
        else if(id==R.id.showall){
            Adapterclass sourcesAdapter = new Adapterclass(MainActivity.this,list);
            listView.setAdapter(sourcesAdapter);
            display = "all";
        }

        return super.onOptionsItemSelected(item);
    }

    public static Comparator<Task> PriorityComparator = new Comparator<Task>() {

        public int compare(Task tempVar1, Task tempVar2) {
            String p1 = String.valueOf(tempVar1.getPriority());
            String p2 = String.valueOf(tempVar2.getPriority());
            //ascending order
            return p2.compareTo(p1);
        }
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listCompleted = new ArrayList<Task>();
        listPending = new ArrayList<Task>();
        list = new ArrayList<Task>();

        // Initialize Realm (just once per application)
        Realm.init(this);

        // Get a Realm instance for this thread
        realm = Realm.getDefaultInstance();

        spinnerPriority = findViewById(R.id.spinnerPriority);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                return super.getView(position, convertView, parent);
            }

            public int getCount() {
                int count = super.getCount();
                if (count > 0) {
                    return count - 1;
                } else {
                    return count;
                }
            }
        };
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        adapter.add("Low");
        adapter.add("High");
        adapter.add("Medium");
        adapter.add("Priority");


        spinnerPriority.setAdapter(adapter);
        spinnerPriority.setSelection(adapter.getCount());
        spinnerPriority.setOnItemSelectedListener(this);
        /*int spinnerPosition = adapter.getPosition("Priority");
        spinnerPriority.setSelection(spinnerPosition);*/



        buttonAdd = findViewById(R.id.buttonAdd);
        listView = findViewById(R.id.list);
        editText = findViewById(R.id.editText);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                task = editText.getText() + "";
                priority=spinnerPriority.getSelectedItem().toString();
                if ((editText.getText().toString()).equals("")) {
                    editText.setError("Value cannot be null");
                    Toast.makeText(MainActivity.this, "Please ", Toast.LENGTH_SHORT).show();
                } else if ((spinnerPriority.getSelectedItem().toString()).equals("Priority")) {
                    Toast.makeText(MainActivity.this, "Please select priority", Toast.LENGTH_SHORT).show();
                } else {
                    realm.beginTransaction();
                    Random rand = new Random();
                    int value = rand.nextInt(1000);
                    Task taskobj = realm.createObject(Task.class,value);
                    taskobj.setName(task);
                    if(priority=="High")
                        taskobj.setPriority("a");
                    else if(priority=="Medium")
                        taskobj.setPriority("b");
                    else if(priority=="Low")
                        taskobj.setPriority("c");

                    taskobj.setDate(Calendar.getInstance().getTime() + "");
                    taskobj.setChecked("no");
                    editText.setText("");
                    spinnerPriority.setAdapter(adapter);
                    spinnerPriority.setSelection(adapter.getCount());
                    spinnerPriority.setOnItemSelectedListener(MainActivity.this);
                    realm.commitTransaction();
                }
            }
        });
        taskRealmResults = realm.where(Task.class).findAll();
        taskRealmResults.addChangeListener(new RealmChangeListener() {
            @Override
            public void onChange(Object tasks) {
                list.clear();
                listCompleted.clear();
                listPending.clear();
                for (Task obj : taskRealmResults) {
                    if((obj.name)!=null) {
                        Log.d("hello", obj.name);
                        //list.add(obj);
                        if ((obj.checked).equals("yes"))
                            listCompleted.add(obj);
                        else if ((obj.checked).equals("no"))
                            listPending.add(obj);
                    }
                }
                Collections.sort(listCompleted, PriorityComparator);
                Collections.sort(listPending, PriorityComparator);
                list.addAll(listPending);
                list.addAll(listCompleted);
                Adapterclass sourcesAdapter = new Adapterclass(MainActivity.this, list);
                listView.setAdapter(sourcesAdapter);
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           final int pos, long id) {
                AlertDialog.Builder alertDialogBuilder;
                alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                alertDialogBuilder.setTitle("Delete Task");
                alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Task obj=list.get(pos);
                        int id=obj.getTaskid();
                        realm.beginTransaction();
                        RealmResults<Task> taskRealmResultsDelete = realm.where(Task.class).equalTo("taskid",id).findAll();
                        taskRealmResultsDelete.deleteAllFromRealm();
                        realm.commitTransaction();
                        //Task obj1 = adapter.mNodes.get(pos);
                        /*list.remove(pos);
                        Adapterclass sourcesAdapter = new Adapterclass(MainActivity.this,list);
                        listView.setAdapter(sourcesAdapter);*/
                        return;
                    }
                });
                alertDialogBuilder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        return;
                    }
                });


                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();

                return true;
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public class Adapterclass extends ArrayAdapter<Task> {
        private Activity context;
        private ArrayList<Task> list;
        //RealmResults<Task> realmResults;


         public Adapterclass(Activity context, List<Task> list){
            super(context,R.layout.list_adapter,list);
            this.context=context;
            this.list= (ArrayList<Task>) list;
        }

        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater= context.getLayoutInflater();
            final Task sources=getItem(position);
            final View listViewItem= LayoutInflater.from(getContext()).inflate(R.layout.list_adapter,null,true);

            TextView textViewName=listViewItem.findViewById(R.id.textViewName);
            TextView textViewPriority=listViewItem.findViewById(R.id.textViewPriority);
            TextView textViewDate=listViewItem.findViewById(R.id.textViewDate);
            CheckBox checkBox=listViewItem.findViewById(R.id.checkBox);
            listViewItem.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    return false;
                }
            });

            textViewName.setText(sources.getName());
            String result=sources.getPriority();

            if (result.equals("a"))
                textViewPriority.setText("High");
            else if (result.equals("b"))
                textViewPriority.setText("Medium");
            else if (result.equals("c"))
                textViewPriority.setText("Low");

            SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
            Date date=new Date();
            try {
                date = sdf.parse(sources.getDate());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            String prettyTime = new PrettyTime().format(date);
            textViewDate.setText(prettyTime);
            if(sources.getChecked().equals("yes")){
                checkBox.setChecked(true);
            }
            else if(sources.getChecked().equals("no")){
                checkBox.setChecked(false);
            }

            checkBox.setTag(position);
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int position = (Integer) buttonView.getTag();
                    int id = list.get(position).getTaskid();

                    if(isChecked){
                        //list.get(position).setChecked("yes");
                        realm.beginTransaction();
                        Task taskEdit = realm.where(Task.class).equalTo("taskid", id).findFirst();
                        taskEdit.setChecked("yes");
                        realm.copyToRealmOrUpdate(taskEdit);
                        realm.commitTransaction();
                    }
                    else {
                        //list.get(position).setChecked("no");
                        realm.beginTransaction();
                        Task taskEdit = realm.where(Task.class).equalTo("taskid", id).findFirst();
                        taskEdit.setChecked("no");
                        realm.copyToRealmOrUpdate(taskEdit);
                        realm.commitTransaction();
                    }
                }
            });

            return listViewItem;
        }
    }
}
